/**
 * Copyright (c) 2005, Paul Tuckey
 * All rights reserved.
 *
 * Each copy or derived work must preserve the copyright notice and this
 * notice unmodified.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
package org.tuckey.web.filters.urlrewrite;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import java.util.Enumeration;
import java.util.Hashtable;


/**
 * Defines a the config that will be passed to the run object on startup.
 *
 * @author Paul Tuckey
 * @version $Revision: 1.2 $ $Date: 2005/12/07 10:27:03 $
 */
public class RunConfig implements ServletConfig {

    private ServletContext servletContext;
    private Hashtable initParameters;

    public RunConfig(ServletContext servletContext, Hashtable initParameters) {
        this.servletContext = servletContext;
        this.initParameters = initParameters;
    }

    public String getServletName() {
        return null;
    }

    public ServletContext getServletContext() {
        return servletContext;
    }

    public String getInitParameter(String s) {
        return (String) initParameters.get(s);
    }

    public Enumeration getInitParameterNames() {
        return initParameters.keys();
    }
}
