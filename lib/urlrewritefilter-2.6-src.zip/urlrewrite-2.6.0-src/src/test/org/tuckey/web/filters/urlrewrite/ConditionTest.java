/**
 * Copyright (c) 2005, Paul Tuckey
 * All rights reserved.
 *
 * Each copy or derived work must preserve the copyright notice and this
 * notice unmodified.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
package org.tuckey.web.filters.urlrewrite;

import junit.framework.TestCase;
import org.tuckey.web.MockRequest;
import org.tuckey.web.filters.urlrewrite.utils.Log;

import javax.servlet.http.Cookie;
import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.Date;

/**
 * @author Paul Tuckey
 * @version $Revision: 1.11 $ $Date: 2005/12/07 10:22:10 $
 */
public class ConditionTest extends TestCase {

    public void setUp() {
        Log.setLevel("DEBUG");
    }


    public void testValue() {
        Condition condition = new Condition();
        condition.setValue("tEster");
        assertEquals("tEster", condition.getValue());
    }

    public void testName() {
        Condition condition = new Condition();
        condition.setName("mename");
        assertEquals("mename", condition.getName());
    }

    public void testType() {

        typeSpecific("time");
        typeSpecific("year");
        typeSpecific("month");
        typeSpecific("dayofmonth");
        typeSpecific("dayofweek");

        typeSpecific("ampm");
        typeSpecific("hourofday");
        typeSpecific("minute");
        typeSpecific("second");
        typeSpecific("millisecond");

        typeSpecific("attribute");
        typeSpecific("auth-type");
        typeSpecific("character-encoding");
        typeSpecific("content-length");
        typeSpecific("content-type");

        typeSpecific("context-path");
        typeSpecific("cookie");
        typeSpecific("header");
        typeSpecific("method");
        typeSpecific("parameter");

        typeSpecific("path-info");
        typeSpecific("path-translated");
        typeSpecific("protocol");
        typeSpecific("query-string");
        typeSpecific("remote-addr");

        typeSpecific("remote-host");
        typeSpecific("remote-user");
        typeSpecific("requested-session-id");
        typeSpecific("request-uri");
        typeSpecific("request-url");

        typeSpecific("session-attribute");
        typeSpecific("session-isnew");
        typeSpecific("port");
        typeSpecific("server-name");
        typeSpecific("scheme");

        typeSpecific("user-in-role");
    }

    public void typeSpecific(String type) {
        Condition condition = new Condition();
        condition.setType(type);
        assertEquals(type, condition.getType());

        // perform a weak test to check for null pointers etc
        MockRequest request = new MockRequest();
        condition.initialise();
        condition.matches(request);
    }

    public void testCompileFailure() {
        Condition condition = new Condition();
        condition.setValue("aaa[");
        assertFalse("regexp shouldn't compile", condition.initialise());
    }

    public void testOperator() {
        Condition condition = new Condition();
        condition.setOperator("");
        assertEquals("equal", condition.getOperator());
    }

    public void testNext() {
        Condition condition = new Condition();
        condition.setNext("and");
        assertEquals("and", condition.getNext());

        Condition condition2 = new Condition();
        condition2.setNext("badand");
        assertFalse("must not init", condition.initialise());

        Condition condition3 = new Condition();
        condition3.setNext("or");
        assertEquals("or", condition3.getNext());
        assertTrue(condition3.isProcessNextOr());
    }

    public void testUnItied() {
        Condition condition = new Condition();
        assertFalse(condition.matches(new MockRequest()));
    }

    public void testCaseSensitive() {
        Condition condition = new Condition();
        condition.setType("header");
        condition.setName("a");
        condition.setValue("aaa");
        condition.setCaseSensitive(true);
        condition.initialise();
        MockRequest request = new MockRequest();
        request.setHeader("a", "aAa");
        assertFalse(condition.matches(request));
        request.setHeader("a", "aaa");
        assertTrue(condition.matches(request));
        assertTrue(condition.isCaseSensitive());
    }

    public void testInvalid() {
        Condition condition = new Condition();
        condition.setType("bogus");
        condition.initialise();
        assertFalse(condition.matches(new MockRequest()));
    }

    public void testId() {
        Condition condition = new Condition();
        condition.setId(98);
        assertTrue(condition.getId() == 98);
    }

    public void testConditionOperator() {
        MockRequest request = new MockRequest();
        request.setServerPort(10);

        Condition condition = new Condition();
        condition.setType("port");
        condition.setValue("9");
        condition.setOperator("greater");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));

        Condition condition2 = new Condition();
        condition2.setType("port");
        condition2.setValue("11");
        condition2.setOperator("less");
        condition2.initialise();
        assertTrue("condition must match", condition2.matches(request));

        Condition condition3 = new Condition();
        condition3.setType("port");
        condition3.setValue("10");
        condition3.setOperator("greaterorequal");
        condition3.initialise();
        assertTrue("condition must match", condition3.matches(request));

        Condition condition4 = new Condition();
        condition4.setType("port");
        condition4.setValue("10");
        condition4.setOperator("lessorequal");
        condition4.initialise();
        assertTrue("condition must match", condition4.matches(request));

        Condition condition5 = new Condition();
        condition5.setType("port");
        condition5.setValue("99");
        condition5.setOperator("notequal");
        condition5.initialise();
        assertTrue("condition must match", condition5.matches(request));

        Condition condition6 = new Condition();
        condition6.setType("method");
        condition6.setValue("POST");
        condition6.setOperator("notequal");
        condition6.initialise();
        assertTrue("condition must match", condition6.matches(request));

        Condition condition7 = new Condition();
        condition7.setType("method");
        condition7.setValue("POST");
        condition7.setOperator("somebadassop");

        assertFalse("condition must not init", condition7.initialise());
        assertTrue("condition must have error", condition7.getError() != null);

    }

    public void testConditionTime() {
        MockRequest request = new MockRequest();
        long field = System.currentTimeMillis();
        Condition condition = new Condition();
        condition.setType("time");
        condition.setValue("" + field);
        condition.setOperator("greaterorequal");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionYear() {
        MockRequest request = new MockRequest();
        Calendar cal = Calendar.getInstance();
        int field = cal.get(Calendar.YEAR);
        Condition condition = new Condition();
        condition.setType("year");
        condition.setValue("" + field);
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionMonth() {
        MockRequest request = new MockRequest();
        Calendar cal = Calendar.getInstance();
        int field = cal.get(Calendar.MONTH);
        Condition condition = new Condition();
        condition.setType("month");
        condition.setValue("" + field);
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionDayOfMonth() {
        MockRequest request = new MockRequest();
        Calendar cal = Calendar.getInstance();
        int field = cal.get(Calendar.DAY_OF_MONTH);
        Condition condition = new Condition();
        condition.setType("dayofmonth");
        condition.setValue("" + field);
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionDayOfWeek() {
        MockRequest request = new MockRequest();
        Calendar cal = Calendar.getInstance();
        int field = cal.get(Calendar.DAY_OF_WEEK);
        Condition condition = new Condition();
        condition.setType("dayofweek");
        condition.setValue("" + field);
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }


    public void testConditionAmPm() {
        MockRequest request = new MockRequest();
        Calendar cal = Calendar.getInstance();
        int field = cal.get(Calendar.AM_PM);
        Condition condition = new Condition();
        condition.setType("ampm");
        condition.setValue("" + field);
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionHourOfDay() {
        MockRequest request = new MockRequest();
        Calendar cal = Calendar.getInstance();
        int field = cal.get(Calendar.HOUR_OF_DAY);
        Condition condition = new Condition();
        condition.setType("hourofday");
        condition.setValue("" + field);
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionMinute() {
        MockRequest request = new MockRequest();
        Calendar cal = Calendar.getInstance();
        int field = cal.get(Calendar.MINUTE);
        Condition condition = new Condition();
        condition.setType("minute");
        condition.setValue("" + field);
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionSecond() {
        MockRequest request = new MockRequest();
        Calendar cal = Calendar.getInstance();
        int field = cal.get(Calendar.SECOND);
        Condition condition = new Condition();
        condition.setType("second");
        condition.setValue("" + field);
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionMillisecond() {
        MockRequest request = new MockRequest();
        Calendar cal = Calendar.getInstance();
        int field = cal.get(Calendar.MILLISECOND);
        Condition condition = new Condition();
        condition.setType("millisecond");
        condition.setValue("" + field);
        condition.setOperator("greaterorequal");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionAttribute() {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("attribute");
        condition.setName("ray");
        condition.setValue("andchristian");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setAttribute("ray", "andchristian");
        assertTrue("condition must match", condition.matches(request));

        Condition condition2 = new Condition();
        condition2.setType("attribute");
        condition2.setName("ray");
        condition2.setValue("andbob");
        condition2.initialise();
        assertFalse("condition must not match", condition2.matches(request));

        Condition condition3 = new Condition();
        condition3.setType("attribute");
        condition3.setValue("andbob");
        condition3.initialise();
        assertFalse("condition must not initialise", condition3.matches(request));
    }

    public void testConditionAuthType() {
        MockRequest request = new MockRequest();
        request.setAuthType("pwdwithcrapasrot13");
        Condition condition = new Condition();
        condition.setType("auth-type");
        condition.setValue("pwd[a-z0-9]+");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));

        Condition condition2 = new Condition();
        condition2.setType("auth-type");
        condition2.setValue("someotherpwdtype");
        condition2.initialise();
        assertFalse("condition must not match", condition2.matches(request));
    }

    public void testConditionCharacterEncoding() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("character-encoding");
        condition.setValue("utfcrazybig[0-9]+");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setCharacterEncoding("utfcrazybig13");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testConditionContentLength() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        request.setContentLength(120);
        Condition condition = new Condition();
        condition.setType("content-length");
        condition.setValue("100");
        condition.setOperator("greater");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));

        request.setContentLength(10);
        assertFalse("condition must not match", condition.matches(request));
    }

    public void testContentType() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        request.setContentType("bottlesandcans");
        Condition condition = new Condition();
        condition.setType("content-type");
        condition.setValue("bott[a-z]+");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));

        request.setContentType(null);
        assertFalse("condition must not match", condition.matches(request));
    }

    public void testContextPath() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        request.setContextPath("blah");
        Condition condition = new Condition();
        condition.setType("context-path");
        condition.setValue("[a-b]lah");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));

        request.setContextPath("qlah");
        assertFalse("condition must not match", condition.matches(request));
    }

    public void testCookie() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("cookie");
        condition.setName("tracker");
        condition.setValue(".*bass.*");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.addCookie(new Cookie("otherokie", "allyourbassisbelongtous"));
        assertFalse("condition must not match", condition.matches(request));

        request.addCookie(new Cookie("tracker", "allyourbassisbelongtous"));
        assertTrue("condition must match", condition.matches(request));
    }

    public void testLocalPort() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        request.setLocalPort(4);
        Condition condition = new Condition();
        condition.setType("local-port");
        condition.setValue("1004");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setLocalPort(1004);
        assertTrue("condition must match", condition.matches(request));
    }

    public void testParameter() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("parameter");
        condition.setName("reqparam");
        condition.setValue("[0-9]+");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.addParameter("reqparam", "1000245");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testPathInfo() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("path-info");
        condition.setValue("afr[aeiou]ca");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setPathInfo("africa");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testPathTranslated() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("path-translated");
        condition.setValue("/!@&");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setPathTranslated("/!@&");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testProtocol() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("protocol");
        condition.setValue("HTTP/1\\.[1-2]");
        condition.initialise();
        request.setProtocol("HTTP/2.0");
        assertFalse("condition must not match", condition.matches(request));

        request.setProtocol("HTTP/1.2");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testQueryString() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("query-string");
        condition.setValue(".*&param=[0-9]+.*");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setQueryString("?aaa=dsdsd&param=2333&asdsa=sdds");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testRemoteAddr() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("remote-addr");
        condition.setValue("192.168.[0-9]+.[0-9]+");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setRemoteAddr("192.168.184.23");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testRemoteHost() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("remote-host");
        condition.setValue("\\w+\\.tuckey.org");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setRemoteHost("toaster.tuckey.org");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testRemoteUser() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("remote-user");
        condition.setValue("p.\\w+");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setRemoteUser("p.smith");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testRequestedSessionId() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("requested-session-id");
        condition.setValue("\\w+\\.sec[0-6]+");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setRequestedSessionId("sdfjsdfhkjhk897fd.sec03");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testRequestUri() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("request-uri");
        condition.setValue("\\d");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setRequestURI("2");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testRequestUrl() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("request-url");
        condition.setValue("\\d");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setRequestURL("2");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testSessionAttribute() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("session-attribute");
        condition.setValue("someval");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        Condition condition2 = new Condition();
        condition2.setType("session-attribute");
        condition2.setName("someatt");
        condition2.setValue("someval");
        condition2.initialise();
        assertFalse("condition must not match", condition2.matches(request));

        request.getSession(true).setAttribute("someatt", "someval");

        Condition condition3 = new Condition();
        condition3.setType("session-attribute");
        condition3.setName("someatt");
        condition3.setValue("someval");
        condition3.initialise();
        assertTrue("condition must match", condition3.matches(request));
    }

    public void testSessionIsNew() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("session-isnew");
        condition.setValue("yes");
        condition.setOperator("notequal");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));

        request.setSessionNew(true);
        assertFalse("condition must not match", condition.matches(request));
    }

    public void testServerName() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("server-name");
        condition.setValue("dev.*");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setServerName("dev.googil.com");
        assertTrue("condition must match", condition.matches(request));
    }

    public void testScheme() throws UnsupportedEncodingException {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setType("scheme");
        condition.setValue("http");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setScheme("http");
        assertTrue("condition must match", condition.matches(request));
    }


    public void testConditionHeader() {
        MockRequest request = new MockRequest();
        Condition condition = new Condition();
        condition.setName("some header");
        condition.setValue("tester");
        condition.initialise();
        assertFalse("condition must not match", condition.matches(request));

        request.setHeader("some header", "tester");
        assertTrue("condition must match", condition.matches(request));

        Condition condition2 = new Condition();
        condition2.setName("  ");
        condition2.setValue("tester");
        assertFalse("condition must not initialise", condition2.initialise());
        assertFalse("condition must not match", condition2.matches(request));

        Condition condition3 = new Condition();
        condition3.setName("bonus");
        assertTrue("condition must initialise and check for exists", condition3.initialise());
        assertFalse("condition must not match", condition3.matches(request));
        request.setHeader("bonus", "tester");
        assertTrue("condition must match", condition3.matches(request));

        Condition condition4 = new Condition();
        condition4.setName("portashed");
        condition4.setOperator("notequal");

        assertTrue("condition must initialise and check for exists", condition4.initialise());
        assertTrue("condition must match", condition4.matches(request));
        request.setHeader("portashed", "tester");
        assertFalse("condition must not match", condition4.matches(request));

    }

    public void testConditionMethod() {
        MockRequest request = new MockRequest();
        request.setMethod("HEAD");
        Condition condition = new Condition();
        condition.setType("method");
        condition.setValue("H[A-Z]AD");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));
    }


    public void testConditionIsUserInRole() {
        MockRequest request = new MockRequest();
        request.addRole("devil");
        Condition condition = new Condition();
        condition.setType("user-in-role");
        condition.setName("devil");
        condition.initialise();
        assertTrue("user should be in this role", condition.matches(request));

        Condition condition2 = new Condition();
        condition2.setType("user-in-role");
        condition2.setName("angel");
        condition2.initialise();
        assertFalse("bad user in role must not match", condition2.matches(request));

        Condition condition3 = new Condition();
        condition3.setType("user-in-role");
        condition3.setValue("devil");
        condition3.initialise();
        assertTrue("value instead of name should match", condition3.matches(request));

        Condition condition4 = new Condition();
        condition4.setType("user-in-role");
        condition4.setValue("admin");
        condition4.setOperator("notequal");
        condition4.initialise();
        assertTrue("value instead of name should match", condition4.matches(request));
    }

    public void testConditionPort() {
        MockRequest request = new MockRequest();
        request.setServerPort(9001);
        Condition condition = new Condition();
        condition.setType("port");
        condition.setValue("9001");
        condition.initialise();
        assertTrue("condition must match", condition.matches(request));

        Condition condition2 = new Condition();
        condition2.setType("port");
        condition2.setValue(" 9001");
        condition2.initialise();
        assertTrue("condition must match", condition2.matches(request));
        // check re-init
        condition2.initialise();
        assertTrue("condition must match", condition2.matches(request));

        Condition condition3 = new Condition();
        condition3.setType("port");
        condition3.setValue("aaa");
        condition3.initialise();
        assertFalse("condition must not match", condition3.matches(request));
    }


}
