/**
 * Copyright (c) 2005, Paul Tuckey
 * All rights reserved.
 *
 * Each copy or derived work must preserve the copyright notice and this
 * notice unmodified.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
package org.tuckey.web.filters.urlrewrite;

import junit.framework.TestCase;
import org.tuckey.web.MockRequest;
import org.tuckey.web.MockResponse;
import org.tuckey.web.MockServletContext;
import org.tuckey.web.filters.urlrewrite.utils.Log;

import javax.servlet.ServletException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;


/**
 * @author Paul Tuckey
 * @version $Revision: 1.7 $ $Date: 2005/12/07 10:22:12 $
 */
public class RunTest extends TestCase {

    MockResponse response;
    MockRequest request;
    MockServletContext servletContext;

    public void setUp() {
        Log.setLevel("DEBUG");
        response = new MockResponse();
        request = new MockRequest();
        servletContext = new MockServletContext();
        TestRunObj.resetTestFlags();
    }

    public void testRun01() throws IllegalAccessException, InvocationTargetException, InstantiationException, IOException, ServletException {
        Run run = new Run();
        run.setClassStr(org.tuckey.web.filters.urlrewrite.TestRunObj.class.getName());
        run.initialise(servletContext);
        assertTrue("Should be a initialised " + run.getError(), run.isValid());
        assertTrue("Should be created now", TestRunObj.getCreatedCount() == 1);
        assertTrue("Should be inited now", TestRunObj.isInitCalled());
        run.execute(request, response);
        assertTrue("Should be invoked", TestRunObj.isRunCalled());
        assertTrue("Should not have been created again", TestRunObj.getCreatedCount() == 1);
        assertFalse("Should not be destroyed", TestRunObj.isDestroyCalled());
        run.destroy();
        assertTrue("Should be destroyed", TestRunObj.isDestroyCalled());
    }

    public void testRunBadObj() throws IllegalAccessException, InvocationTargetException, InstantiationException, IOException, ServletException {
        Run run = new Run();
        run.setClassStr("this.is.an.not.found.Class");
        run.initialise(servletContext);
        assertFalse("Should not be initialised " + run.getError(), run.isValid());
        run.execute(request, response);
        // Should not error just do nothing
    }

    public void testRunBadMethod() throws IOException, ServletException {
        Run run = new Run();
        run.setClassStr(org.tuckey.web.filters.urlrewrite.TestRunObj.class.getName());
        run.setMethodStr("badMethod");
        run.initialise(servletContext);
        assertFalse("Should not be initialised " + run.getError(), run.isValid());
        run.execute(request, response);
        // Should not error just do nothing
    }

    public void testRunThatReturns() throws IOException, ServletException {
        Run run = new Run();
        run.setClassStr(org.tuckey.web.filters.urlrewrite.TestRunObj.class.getName());
        run.setMethodStr("runThatReturns");
        run.initialise(servletContext);
        assertTrue("Should be initialised " + run.getError(), run.isValid());
        run.execute(request, response);
        // Should not error just do nothing
    }

    public void testRunCustomMethod() throws IOException, ServletException {
        Run run = new Run();
        run.setClassStr(org.tuckey.web.filters.urlrewrite.TestRunObj.class.getName());
        run.setMethodStr("nonDefaultRun");
        run.initialise(servletContext);
        assertTrue("Should be initialised " + run.getError(), run.isValid());
        run.execute(request, response);
        assertTrue("Should be invoked", TestRunObj.isNonDefaultRunCalled());
        // Should not error just do nothing
    }

    private Throwable doExceptionRun(String methodName) {
        Run run = new Run();
        run.setClassStr(org.tuckey.web.filters.urlrewrite.TestRunObj.class.getName());
        run.setMethodStr(methodName);
        run.initialise(servletContext);
        assertTrue("Should be initialised, but: " + run.getError(), run.isValid());

        Throwable throwableViaRun = null;

        System.out.println("this...");
        try {
            run.execute(request, response);
        } catch (Throwable t) {
            throwableViaRun = t;
            t.printStackTrace(System.out);
        }
        return throwableViaRun;
    }

    public void testRunExceptionMethod() {
        Throwable throwableViaRun = doExceptionRun("runNullPointerException");
        Throwable throwableRaw = null;
        System.out.println("should look the same as this...");
        try {
            new TestRunObj().runNullPointerException(null, null);
        } catch (Throwable t) {
            throwableRaw = t;
            t.printStackTrace(System.out);
        }
        assertEquals(throwableRaw.toString(), throwableViaRun.toString());
    }

    public void testRunServletExceptionMethod() {
        Throwable throwableViaRun = doExceptionRun("runServletException");
        Throwable throwableRaw = null;
        System.out.println("should look the same as this...");
        TestRunObj testRunObj = new TestRunObj();
        try {
            testRunObj.runServletException(null, null);
        } catch (Throwable t) {
            throwableRaw = t;
            t.printStackTrace(System.out);
        }
        assertEquals(throwableRaw.toString(), throwableViaRun.toString());
    }

    public void testRunCustomExceptionMethod() {
        Throwable throwableViaRun = doExceptionRun("runCustomException");
        Throwable throwableRaw = null;
        System.out.println("should look the same as this...");
        TestRunObj testRunObj = new TestRunObj();
        try {
            testRunObj.runCustomException(null, null);
        } catch (Throwable t) {
            throwableRaw = t;
            t.printStackTrace(System.out);
        }
        assertEquals(throwableRaw.toString(), throwableViaRun.getCause().toString());
    }

    public void testRunIOExceptionMethod() {
        Throwable throwableViaRun = doExceptionRun("runIOException");
        Throwable throwableRaw = null;
        System.out.println("should look the same as this...");
        TestRunObj testRunObj = new TestRunObj();
        try {
            testRunObj.runIOException(null, null);
        } catch (Throwable t) {
            throwableRaw = t;
            t.printStackTrace(System.out);
        }
        assertEquals(throwableRaw.toString(), throwableViaRun.toString());
    }

    public void testRunRuntimeExceptionMethod() {
        Throwable throwableViaRun = doExceptionRun("runRuntiumeException");
        Throwable throwableRaw = null;
        System.out.println("should look the same as this...");
        TestRunObj testRunObj = new TestRunObj();
        try {
            testRunObj.runRuntiumeException(null, null);
        } catch (Throwable t) {
            throwableRaw = t;
            t.printStackTrace(System.out);
        }
        assertEquals(throwableRaw.toString(), throwableViaRun.toString());
    }

    public void testRunPrivateMethod() throws IOException, ServletException {
        Run run = new Run();
        run.setClassStr(org.tuckey.web.filters.urlrewrite.TestRunObj.class.getName());
        run.setMethodStr("privateRun");
        run.initialise(servletContext);
        assertFalse("Should not be initialised " + run.getError(), run.isValid());
        run.execute(request, response);
        // Should not error just do nothing, check log msgs
    }

    public void testRunNewEach() throws IOException, ServletException {
        Run run = new Run();
        run.setClassStr(org.tuckey.web.filters.urlrewrite.TestRunObj.class.getName());
        run.setNewEachTime(true);
        run.initialise(servletContext);
        assertTrue("Should not have been created yet", TestRunObj.getCreatedCount() == 0);
        run.execute(request, response);
        assertTrue("Should be created now", TestRunObj.getCreatedCount() == 1);
        run.execute(request, response);
        assertTrue("Should be created twice", TestRunObj.getCreatedCount() == 2);
        assertTrue("Should be destroyed", TestRunObj.isDestroyCalled());
    }

    public void testInitParams() {
        Run run = new Run();
        run.setClassStr(org.tuckey.web.filters.urlrewrite.TestRunObj.class.getName());
        run.addInitParam("horse", "golden");
        run.addInitParam("debs", "nightout");
        run.initialise(servletContext);
        assertEquals("golden", TestRunObj.getTestServletConfig().getInitParameter("horse"));
        assertEquals("nightout", TestRunObj.getTestServletConfig().getInitParameter("debs"));
    }

    public void testRuleNoToWithRun() throws IOException, ServletException {
        Run run = new Run();
        run.setClassStr(org.tuckey.web.filters.urlrewrite.TestRunObj.class.getName());
        run.setMethodStr("run");
        Rule rule = new Rule();
        rule.setFrom("from");
        rule.addRun(run);
        rule.initialise(null);
        MockRequest request = new MockRequest("from");

        RewrittenUrl rewrittenUrl = rule.execute(request.getRequestURI(), request, response);
        assertNull(rewrittenUrl);
        assertTrue(TestRunObj.isRunCalled());
    }


}
